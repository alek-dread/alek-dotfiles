#define _POSIX_C_SOURCE 200809L

#include <time.h>
#include <assert.h>

#include <glib/gi18n.h>

#include <gtk/gtk.h>

#include "actions.h"
#include "proto.h"
#include "gtkgreet.h"
#include "window.h"

static void handle_response(struct response resp, int start_req);

static void wipe_secret(void *buffer, size_t size) {
    volatile unsigned char *p = buffer;
    while (size--) *p++ = 0;
}

static void request_worker(GTask *task, gpointer source, gpointer data, GCancellable *cancel) {
    struct request *req = data;
    struct response *resp = g_new(struct response, 1);
    *resp = roundtrip(*req);
    if (req->request_type == request_type_post_auth_message_response)
        wipe_secret(&req->body, sizeof(req->body));
    g_task_return_pointer(task, resp, g_free);
}

static void request_completed(GObject *source, GAsyncResult *result, gpointer data) {
    GTask *task = G_TASK(result);
    struct request *req = g_task_get_task_data(task);
    struct response *resp = g_task_propagate_pointer(task, NULL);
    gtkgreet->starting_session = FALSE;
    gtkgreet_set_busy(gtkgreet, FALSE);
    if (req->request_type == request_type_cancel_session) {
        gtkgreet->cancel_pending = FALSE;
        if (resp->response_type != response_type_success)
            gtkgreet_setup_question(gtkgreet, QuestionTypeInitial, gtkgreet_get_initial_question(),
                "Could not reset sign-in. Please try again.");
    } else if (gtkgreet->cancel_pending) {
        gtkgreet->cancel_pending = FALSE;
        action_cancel_question(NULL, NULL);
    } else {
        handle_response(*resp, req->request_type == request_type_start_session);
    }
    g_free(resp);
    g_application_release(G_APPLICATION(gtkgreet->app));
}

static void queue_request(const struct request *req) {
    struct request *copy = g_memdup2(req, sizeof(*req));
    gtkgreet->starting_session = req->request_type == request_type_start_session;
    gtkgreet_set_busy(gtkgreet, TRUE);
    g_application_hold(G_APPLICATION(gtkgreet->app));
    GTask *task = g_task_new(NULL, NULL, request_completed, NULL);
    g_task_set_task_data(task, copy, g_free);
    g_task_run_in_thread(task, request_worker);
    g_object_unref(task);
}

static void handle_response(struct response resp, int start_req) {
    switch (resp.response_type) {
        case response_type_success: {
            if (start_req) {
                GError *error = NULL;
                if (gtkgreet->username != NULL &&
                    !g_file_set_contents(GTKGREET_STATE_FILE, gtkgreet->username, -1, &error)) {
                    g_warning("Could not remember username: %s", error->message);
                    g_error_free(error);
                }
                exit(0);
            }
            struct request req = {
                .request_type = request_type_start_session,
            };
            strncpy(req.body.request_start_session.cmd, gtkgreet->selected_command, 127);
            queue_request(&req);
            break;
        }
        case response_type_auth_message: {
            if (start_req) {
                struct request req = {
                    .request_type = request_type_cancel_session,
                };
                queue_request(&req);

                char *error = _("Unexpected auth question");
                gtkgreet_setup_question(gtkgreet, QuestionTypeInitial, gtkgreet_get_initial_question(), error);
                break;
            }

            gtkgreet_setup_question(gtkgreet,
                (enum QuestionType)resp.body.response_auth_message.auth_message_type,
                resp.body.response_auth_message.auth_message,
                NULL);
            break;
        }
        case response_type_roundtrip_error:
        case response_type_error: {
            struct request req = {
                .request_type = request_type_cancel_session,
            };
            queue_request(&req);

            char* error = NULL;
            if (resp.response_type == response_type_error &&
                resp.body.response_error.error_type == error_type_auth) {
                error = _("Login failed");
            } else {
                error = resp.body.response_error.description;
            }
            gtkgreet_setup_question(gtkgreet, QuestionTypeInitial, gtkgreet_get_initial_question(), error);
            break;
        }
    }
}

void action_use_remembered_user(void) {
    if (gtkgreet->username == NULL || gtkgreet->username[0] == '\0' ||
        gtkgreet->question_type != QuestionTypeInitial || gtkgreet->windows->len == 0) {
        return;
    }
    struct Window *ctx = gtkgreet->focused_window != NULL ? gtkgreet->focused_window :
        g_array_index(gtkgreet->windows, struct Window*, 0);
    action_answer_question(NULL, ctx);
}

void action_answer_question(GtkWidget *widget, gpointer data) {
    if (gtkgreet->busy) return;
    struct Window *ctx = data;
    switch (gtkgreet->question_type) {
        case QuestionTypeInitial: {
            const char *command = gtk_combo_box_get_active_id(GTK_COMBO_BOX(ctx->command_selector));
            const char *username = gtk_entry_get_text(GTK_ENTRY(ctx->input_field));
            if (command == NULL || command[0] == '\0' || strlen(command) >= sizeof(((struct request_start_session*)0)->cmd)) {
                gtkgreet_setup_question(gtkgreet, QuestionTypeInitial, gtkgreet_get_initial_question(), "Select a valid session.");
                return;
            }
            if (username[0] == '\0' || strlen(username) >= sizeof(((struct request_create_session*)0)->username)) {
                gtkgreet_setup_question(gtkgreet, QuestionTypeInitial, gtkgreet_get_initial_question(), "Enter a username of at most 127 bytes.");
                return;
            }
            if (gtkgreet->selected_command) {
                free(gtkgreet->selected_command);
                gtkgreet->selected_command = NULL;
            }
            gtkgreet->selected_command = g_strdup(gtk_combo_box_get_active_id(GTK_COMBO_BOX(ctx->command_selector)));

            struct request req = {
                .request_type = request_type_create_session,
            };
            if (ctx->input_field != NULL) {
                strncpy(req.body.request_create_session.username, gtk_entry_get_text((GtkEntry*)ctx->input_field), 127);
            }
            g_free(gtkgreet->username);
            gtkgreet->username = g_strdup(req.body.request_create_session.username);
            queue_request(&req);
            break;
        }
        case QuestionTypeSecret:
        case QuestionTypeVisible: {
            struct request req = {
                .request_type = request_type_post_auth_message_response,
            };
            if (ctx->input_field != NULL) {
                const char *text = gtk_entry_get_text(GTK_ENTRY(ctx->input_field));
                if (strlen(text) >= sizeof(req.body.request_post_auth_message_response.response)) {
                    gtkgreet_setup_question(gtkgreet, gtkgreet->question_type, gtkgreet->question,
                        "Response is too long (maximum 1023 bytes). It was not submitted.");
                    return;
                }
                g_strlcpy(req.body.request_post_auth_message_response.response, text,
                    sizeof(req.body.request_post_auth_message_response.response));
                gtk_entry_set_visibility(GTK_ENTRY(ctx->input_field), FALSE);
                gtk_entry_set_text(GTK_ENTRY(ctx->input_field), "");
            }
            queue_request(&req);
            wipe_secret(&req.body, sizeof(req.body));
            break;
        }
        case QuestionTypeInfo:
        case QuestionTypeError: {
            struct request req = {
                .request_type = request_type_post_auth_message_response,
            };
            req.body.request_post_auth_message_response.response[0] = '\0';
            queue_request(&req);
            break;
        }
    }
}

void action_cancel_question(GtkWidget *widget, gpointer data) {
    if (gtkgreet->busy) {
        /* Serialize IPC: do not race a second request against PAM's response. */
        if (!gtkgreet->starting_session) {
            gtkgreet->cancel_pending = TRUE;
            gtkgreet_set_busy(gtkgreet, TRUE);
        }
        return;
    }
    struct request req = {
        .request_type = request_type_cancel_session,
    };
    queue_request(&req);
    gtkgreet_setup_question(gtkgreet, QuestionTypeInitial, gtkgreet_get_initial_question(), NULL);
}

static void power_finished(GObject *source, GAsyncResult *result, gpointer data) {
    GError *error = NULL;
    if (!g_subprocess_wait_check_finish(G_SUBPROCESS(source), result, &error)) {
        GtkWidget *dialog = gtk_message_dialog_new(NULL, GTK_DIALOG_MODAL,
            GTK_MESSAGE_ERROR, GTK_BUTTONS_CLOSE, "Power action failed: %s", error->message);
        g_signal_connect_swapped(dialog, "response", G_CALLBACK(gtk_widget_destroy), dialog);
        gtk_widget_show(dialog);
        g_error_free(error);
    }
    g_object_unref(source);
}

static void power_confirmed(GtkDialog *dialog, gint response, gpointer data) {
    gtk_widget_destroy(GTK_WIDGET(dialog));
    if (response != GTK_RESPONSE_YES) {
        return;
    }
    GError *error = NULL;
    GSubprocess *process = g_subprocess_new(G_SUBPROCESS_FLAGS_NONE, &error,
        GTKGREET_SYSTEMCTL, "--no-ask-password", (const char *)data, NULL);
    if (process == NULL) {
        g_warning("Power action failed: %s", error->message);
        g_error_free(error);
        return;
    }
    g_subprocess_wait_check_async(process, NULL, power_finished, NULL);
}

void action_power(GtkWidget *widget, gpointer data) {
    const char *action = data;
    GtkWidget *dialog = gtk_message_dialog_new(
        GTK_WINDOW(gtk_widget_get_toplevel(widget)), GTK_DIALOG_MODAL,
        GTK_MESSAGE_QUESTION, GTK_BUTTONS_YES_NO,
        "%s", strcmp(action, "reboot") == 0 ? "Restart the computer?" : "Shut down the computer?");
    gtk_dialog_set_default_response(GTK_DIALOG(dialog), GTK_RESPONSE_NO);
    g_signal_connect(dialog, "response", G_CALLBACK(power_confirmed), data);
    gtk_widget_show(dialog);
}
