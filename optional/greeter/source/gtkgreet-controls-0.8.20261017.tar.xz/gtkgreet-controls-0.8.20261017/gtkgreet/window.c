#define _POSIX_C_SOURCE 200809L

#include <time.h>
#include <assert.h>

#include <glib/gi18n.h>

#include <gtk/gtk.h>

#include "proto.h"
#include "window.h"
#include "gtkgreet.h"
#include "actions.h"
#include "config.h"

static void window_set_focus(struct Window *win, struct Window *old);

#ifdef LAYER_SHELL
#   include <gtk-layer-shell.h>

    static void window_set_focus_layer_shell(struct Window *win, struct Window *old) {
        if (old != NULL) {
            gtk_layer_set_keyboard_interactivity(GTK_WINDOW(old->window), FALSE);
        }
        gtk_layer_set_keyboard_interactivity(GTK_WINDOW(win->window), TRUE);
    }

    static gboolean window_enter_notify(GtkWidget *widget, gpointer data) {
        struct Window *win = gtkgreet_window_by_widget(gtkgreet, widget);
        gtkgreet_focus_window(gtkgreet, win);
        return FALSE;
    }

    static void window_setup_layershell(struct Window *ctx) {
            gtk_widget_add_events(ctx->window, GDK_ENTER_NOTIFY_MASK);
        if (ctx->enter_notify_handler > 0) {
            g_signal_handler_disconnect(ctx->window, ctx->enter_notify_handler);
            ctx->enter_notify_handler = 0;
        }
        ctx->enter_notify_handler = g_signal_connect(ctx->window, "enter-notify-event", G_CALLBACK(window_enter_notify), NULL);

        gtk_layer_init_for_window(GTK_WINDOW(ctx->window));
        gtk_layer_set_layer(GTK_WINDOW(ctx->window), GTK_LAYER_SHELL_LAYER_TOP);
        gtk_layer_set_monitor(GTK_WINDOW(ctx->window), ctx->monitor);
        gtk_layer_auto_exclusive_zone_enable(GTK_WINDOW(ctx->window));
        gtk_layer_set_anchor(GTK_WINDOW(ctx->window), GTK_LAYER_SHELL_EDGE_LEFT, TRUE);
        gtk_layer_set_anchor(GTK_WINDOW(ctx->window), GTK_LAYER_SHELL_EDGE_RIGHT, TRUE);
        gtk_layer_set_anchor(GTK_WINDOW(ctx->window), GTK_LAYER_SHELL_EDGE_TOP, TRUE);
        gtk_layer_set_anchor(GTK_WINDOW(ctx->window), GTK_LAYER_SHELL_EDGE_BOTTOM, TRUE);
    }

#endif

void window_update_clock(struct Window *ctx) {
    if (ctx->clock_label != NULL) {
        gtk_label_set_text(GTK_LABEL(ctx->clock_label), gtkgreet->time);
    }
}

static gboolean draw_wordmark(GtkWidget *widget, cairo_t *cr, gpointer data) {
    /* FEDORA: preserve pixel geometry; obtain the color from GTK CSS. */
    static const unsigned char glyphs[6][7] = {
        {31,16,16,30,16,16,16}, {31,16,16,30,16,16,31},
        {30,17,17,17,17,17,30}, {14,17,17,17,17,17,14},
        {30,17,17,30,20,18,17}, {14,17,17,31,17,17,17}
    };
    const int cell = 8, width = 35 * cell;
    const int x = (gtk_widget_get_allocated_width(widget) - width) / 2;
    cairo_set_antialias(cr, CAIRO_ANTIALIAS_NONE);
    GdkRGBA color;
    gtk_style_context_get_color(gtk_widget_get_style_context(widget),
                                gtk_widget_get_state_flags(widget), &color);
    gdk_cairo_set_source_rgba(cr, &color);
    for (int letter = 0; letter < 6; letter++) {
        for (int row = 0; row < 7; row++) {
            for (int col = 0; col < 5; col++) {
                if (glyphs[letter][row] & (1 << (4 - col))) {
                    cairo_rectangle(cr, x + (letter * 6 + col) * cell,
                                    row * cell, cell, cell);
                }
            }
        }
    }
    cairo_fill(cr);
    return FALSE;
}

static GtkWidget *form_row(const char *text, GtkWidget *field) {
    GtkWidget *row = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 12);
    GtkWidget *label = gtk_label_new(text);
    gtk_widget_set_name(label, "field-label");
    gtk_label_set_xalign(GTK_LABEL(label), 0);
    gtk_label_set_line_wrap(GTK_LABEL(label), TRUE);
    gtk_label_set_max_width_chars(GTK_LABEL(label), 11);
    gtk_widget_set_size_request(label, 82, -1);
    gtk_box_pack_start(GTK_BOX(row), label, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(row), field, TRUE, TRUE, 0);
    return row;
}

static gboolean window_key_press(GtkWidget *widget, GdkEventKey *event, gpointer data) {
    struct Window *ctx = data;
    if (event->keyval == GDK_KEY_Escape && gtkgreet->focused_window == ctx &&
        (gtkgreet->question_type != QuestionTypeInitial || gtkgreet->busy)) {
        action_cancel_question(widget, ctx);
        return TRUE;
    }
    return FALSE;
}

void on_visibility_icon_press(GtkWidget *widget, GtkEntryIconPosition position,
                              GdkEvent *event, gpointer data) {
    gboolean visible = gtk_entry_get_visibility(GTK_ENTRY(widget));

    if (visible) {
        gtk_entry_set_visibility(GTK_ENTRY(widget), FALSE);
        gtk_entry_set_icon_from_icon_name(GTK_ENTRY(widget), GTK_ENTRY_ICON_SECONDARY, "view-reveal-symbolic");
    } else {
        gtk_entry_set_visibility(GTK_ENTRY(widget), TRUE);
        gtk_entry_set_icon_from_icon_name(GTK_ENTRY(widget), GTK_ENTRY_ICON_SECONDARY, "view-conceal-symbolic");
    }
}

void window_setup_question(struct Window *ctx, enum QuestionType type, char* question, char* error) {
    if (gtkgreet->focused_window != NULL && ctx != gtkgreet->focused_window) {
        return;
    }

    if (ctx->input_box != NULL) {
        if (gtkgreet->question_cnt == ctx->question_cnt) {
            return;
        }

        gtk_widget_destroy(ctx->input_box);
        ctx->input_box = NULL;

        // Children of the box
        ctx->input_field = NULL;
        ctx->command_selector = NULL;
    }
    ctx->input_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 12);
    ctx->continue_button = NULL;
    GtkWidget *session;
    if (type == QuestionTypeInitial) {
        ctx->command_selector = gtk_combo_box_text_new();
        session = ctx->command_selector;
        gtk_widget_set_name(session, "command-selector");
        config_update_command_selector(session);
        gtk_combo_box_set_active(GTK_COMBO_BOX(session), 0);
    } else {
        const char *command = gtkgreet->selected_command;
        session = gtk_label_new(command != NULL &&
            strcmp(command, "/usr/local/bin/greetd-session/Hyprland") != 0
                ? command : "Hyprland (Wayland)");
        gtk_label_set_xalign(GTK_LABEL(session), 0);
        gtk_label_set_ellipsize(GTK_LABEL(session), PANGO_ELLIPSIZE_END);
    }
    gtk_container_add(GTK_CONTAINER(ctx->input_box), form_row("Session:", session));
    /* Keep the session row at the same height in every authentication state. */
    gtk_widget_set_size_request(session, -1, 31);
    if (type != QuestionTypeInitial && gtkgreet->username != NULL) {
        GtkWidget *username = gtk_label_new(gtkgreet->username);
        gtk_label_set_xalign(GTK_LABEL(username), 0);
        gtk_label_set_ellipsize(GTK_LABEL(username), PANGO_ELLIPSIZE_END);
        gtk_container_add(GTK_CONTAINER(ctx->input_box), form_row("Username:", username));
    }

    switch (type) {
        case QuestionTypeInitial:
        case QuestionTypeVisible:
        case QuestionTypeSecret: {
            ctx->input_field = gtk_entry_new();
            gtk_widget_set_name(ctx->input_field, "input-field");
            if (type == QuestionTypeInitial && gtkgreet->username != NULL) {
                gtk_entry_set_text(GTK_ENTRY(ctx->input_field), gtkgreet->username);
            }
            if (type == QuestionTypeSecret) {
                gtk_entry_set_input_purpose(GTK_ENTRY(ctx->input_field), GTK_INPUT_PURPOSE_PASSWORD);
                gtk_entry_set_input_hints(GTK_ENTRY(ctx->input_field), GTK_INPUT_HINT_NO_SPELLCHECK | GTK_INPUT_HINT_NO_EMOJI);
                gtk_entry_set_visibility(GTK_ENTRY(ctx->input_field), FALSE);
                gtk_entry_set_icon_from_icon_name(GTK_ENTRY(ctx->input_field), GTK_ENTRY_ICON_SECONDARY, "view-reveal-symbolic");
                gtk_entry_set_icon_tooltip_text(GTK_ENTRY(ctx->input_field), GTK_ENTRY_ICON_SECONDARY, "Show or hide password");
                gtk_entry_set_icon_activatable(GTK_ENTRY(ctx->input_field), GTK_ENTRY_ICON_SECONDARY, TRUE);
                g_signal_connect(ctx->input_field, "icon-press", G_CALLBACK(on_visibility_icon_press), NULL);
            }
            g_signal_connect(ctx->input_field, "activate", G_CALLBACK(action_answer_question), ctx);
            gtk_widget_set_size_request(ctx->input_field, 220, -1);
            GtkWidget *row = form_row(question, ctx->input_field);
            gtk_container_add(GTK_CONTAINER(ctx->input_box), row);
            GList *children = gtk_container_get_children(GTK_CONTAINER(row));
            gtk_label_set_mnemonic_widget(GTK_LABEL(children->data), ctx->input_field);
            atk_object_set_name(gtk_widget_get_accessible(ctx->input_field), question);
            g_list_free(children);
            break;
        }
        case QuestionTypeInfo:
        case QuestionTypeError: {
            GtkWidget *label = gtk_label_new(question);
            gtk_label_set_line_wrap(GTK_LABEL(label), TRUE);
            gtk_label_set_max_width_chars(GTK_LABEL(label), 36);
            gtk_label_set_xalign(GTK_LABEL(label), 0);
            if (type == QuestionTypeError) gtk_widget_set_name(label, "error");
            gtk_container_add(GTK_CONTAINER(ctx->input_box), label);
            break;
        }
    }
    if (error != NULL) {
        GtkWidget *label = gtk_label_new(error);
        gtk_widget_set_name(label, "error");
        gtk_label_set_line_wrap(GTK_LABEL(label), TRUE);
        gtk_label_set_max_width_chars(GTK_LABEL(label), 36);
        gtk_label_set_xalign(GTK_LABEL(label), 0);
        gtk_container_add(GTK_CONTAINER(ctx->input_box), label);
    }
    gtk_container_add(GTK_CONTAINER(ctx->form), ctx->input_box);

    GtkWidget *button_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 12);
    gtk_widget_set_halign(button_box, GTK_ALIGN_END);
    gtk_widget_set_margin_top(button_box, 6);
    gtk_container_add(GTK_CONTAINER(ctx->input_box), button_box);
    if (type != QuestionTypeInitial) {
        GtkWidget *cancel_button = gtk_button_new_with_label("Change user");
        gtk_container_add(GTK_CONTAINER(button_box), cancel_button);
        g_signal_connect(cancel_button, "clicked", G_CALLBACK(action_cancel_question), ctx);
    }
    GtkWidget *continue_button = gtk_button_new_with_label("Continue →");
    ctx->continue_button = continue_button;
    g_signal_connect(continue_button, "clicked", G_CALLBACK(action_answer_question), ctx);
    gtk_style_context_add_class(gtk_widget_get_style_context(continue_button), "suggested-action");
    gtk_container_add(GTK_CONTAINER(button_box), continue_button);

    gtk_widget_show_all(ctx->window);
    gtkgreet_set_busy(gtkgreet, gtkgreet->busy);

    if (ctx->input_field != NULL) {
        gtk_widget_grab_focus(ctx->input_field);
    }
}

static void window_empty(struct Window *ctx) {
    if (ctx->overlay != NULL) {
        gtk_widget_destroy(ctx->overlay);
        ctx->overlay = NULL;
        ctx->revealer = NULL;
    }

    ctx->window_box = NULL;
    ctx->clock_label = NULL;
    ctx->body = NULL;
    ctx->form = NULL;
    ctx->input_box = NULL;
    ctx->input_field = NULL;
    ctx->command_selector = NULL;
    ctx->continue_button = NULL;
}

static void window_setup(struct Window *ctx) {
    if (ctx->overlay == NULL) {
        ctx->overlay = gtk_overlay_new();
        gtk_container_add(GTK_CONTAINER(ctx->window), ctx->overlay);
        ctx->revealer = gtk_revealer_new();
        gtk_widget_set_halign(ctx->revealer, GTK_ALIGN_CENTER);
        gtk_widget_set_valign(ctx->revealer, GTK_ALIGN_CENTER);
        gtk_widget_set_margin_start(ctx->revealer, 24);
        gtk_widget_set_margin_end(ctx->revealer, 24);
        gtk_container_add(GTK_CONTAINER(ctx->overlay), ctx->revealer);
        gtk_revealer_set_transition_type(GTK_REVEALER(ctx->revealer), GTK_REVEALER_TRANSITION_TYPE_NONE);
        gtk_revealer_set_reveal_child(GTK_REVEALER(ctx->revealer), TRUE);

        ctx->clock_label = gtk_label_new("");
        gtk_widget_set_name(ctx->clock_label, "clock");
        gtk_widget_set_halign(ctx->clock_label, GTK_ALIGN_END);
        gtk_widget_set_valign(ctx->clock_label, GTK_ALIGN_START);
        gtk_widget_set_margin_top(ctx->clock_label, 32);
        gtk_widget_set_margin_end(ctx->clock_label, 40);
        gtk_overlay_add_overlay(GTK_OVERLAY(ctx->overlay), ctx->clock_label);
        window_update_clock(ctx);

        GtkWidget *shortcuts = gtk_label_new("Tab focus   ·   Enter continue   ·   Esc cancel");
        gtk_widget_set_name(shortcuts, "shortcuts");
        gtk_widget_set_halign(shortcuts, GTK_ALIGN_CENTER);
        gtk_widget_set_valign(shortcuts, GTK_ALIGN_END);
        gtk_widget_set_margin_bottom(shortcuts, 34);
        gtk_overlay_add_overlay(GTK_OVERLAY(ctx->overlay), shortcuts);

        GtkWidget *power = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 14);
        gtk_widget_set_name(power, "power");
        gtk_widget_set_halign(power, GTK_ALIGN_END);
        gtk_widget_set_valign(power, GTK_ALIGN_END);
        gtk_widget_set_margin_end(power, 36);
        gtk_widget_set_margin_bottom(power, 26);
        gtk_overlay_add_overlay(GTK_OVERLAY(ctx->overlay), power);
        GtkWidget *reboot = gtk_button_new_with_label("Reboot");
        GtkWidget *shutdown = gtk_button_new_with_label("Shut down");
        gtk_container_add(GTK_CONTAINER(power), reboot);
        gtk_container_add(GTK_CONTAINER(power), shutdown);
        g_signal_connect(reboot, "clicked", G_CALLBACK(action_power), "reboot");
        g_signal_connect(shutdown, "clicked", G_CALLBACK(action_power), "poweroff");
    }
    if (ctx->window_box == NULL) {
        ctx->window_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
        gtk_widget_set_name(ctx->window_box, "window");
        gtk_container_add(GTK_CONTAINER(ctx->revealer), ctx->window_box);
        gchar *version = g_get_os_info(G_OS_INFO_KEY_VERSION_ID);
        gchar *caption = version != NULL && version[0] != '\0'
            ? g_strdup_printf("── ////// %s ////// ──", version)
            : g_strdup("── ////// FEDORA ////// ──");
        GtkWidget *eyebrow = gtk_label_new(caption);
        g_free(caption);
        g_free(version);
        gtk_widget_set_name(eyebrow, "eyebrow");
        gtk_widget_set_margin_bottom(eyebrow, 18);
        gtk_container_add(GTK_CONTAINER(ctx->window_box), eyebrow);
        GtkWidget *wordmark = gtk_drawing_area_new();
        gtk_widget_set_name(wordmark, "fedora-wordmark");
        gtk_widget_set_size_request(wordmark, 376, 56);
        gtk_widget_set_margin_bottom(wordmark, 42);
        atk_object_set_name(gtk_widget_get_accessible(wordmark), "Fedora");
        g_signal_connect(wordmark, "draw", G_CALLBACK(draw_wordmark), NULL);
        gtk_container_add(GTK_CONTAINER(ctx->window_box), wordmark);
    }

    // Update input area if necessary
    if (gtkgreet->focused_window == ctx || gtkgreet->focused_window == NULL) {
        if (ctx->body == NULL) {
            ctx->body = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
            gtk_widget_set_halign(ctx->body, GTK_ALIGN_CENTER);
            gtk_widget_set_name(ctx->body, "body");
            /* A bounded viewport prevents prompts/errors from resizing the panel. */
            GtkWidget *viewport = gtk_scrolled_window_new(NULL, NULL);
            gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(viewport),
                GTK_POLICY_NEVER, GTK_POLICY_AUTOMATIC);
            gtk_widget_set_size_request(viewport, 380, 180);
            ctx->form = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
            gtk_container_add(GTK_CONTAINER(viewport), ctx->form);
            gtk_container_add(GTK_CONTAINER(ctx->body), viewport);
            gtk_container_add(GTK_CONTAINER(ctx->window_box), ctx->body);
            window_update_clock(ctx);
        }
        window_setup_question(ctx, gtkgreet->question_type, gtkgreet->question, gtkgreet->error);
    } else if (ctx->body != NULL) {
        gtk_widget_destroy(ctx->body);
        ctx->body = NULL;
        ctx->form = NULL;
        ctx->input_box = NULL;
        ctx->input_field = NULL;
        ctx->command_selector = NULL;
        ctx->continue_button = NULL;
        window_update_clock(ctx);
    }

    if (ctx->revealer != NULL) {
        gtk_revealer_set_transition_type(GTK_REVEALER(ctx->revealer), GTK_REVEALER_TRANSITION_TYPE_NONE);
        gtk_revealer_set_reveal_child(GTK_REVEALER(ctx->revealer), TRUE);
    }

    ctx->question_cnt = gtkgreet->question_cnt;
}

static void window_destroy_notify(GtkWidget *widget, gpointer data) {
    window_empty(gtkgreet_window_by_widget(gtkgreet, widget));
    gtkgreet_remove_window_by_widget(gtkgreet, widget);
}

static void window_set_focus(struct Window *win, struct Window *old) {
    assert(win != NULL);

    window_setup(win);

    if (old != NULL && old != win) {
        if (old->input_field != NULL && win->input_field != NULL) {
            // Get previous cursor position
            gint cursor_pos = 0;
            g_object_get((GtkEntry*)old->input_field, "cursor-position", &cursor_pos, NULL);

            // Move content
            gtk_entry_set_text((GtkEntry*)win->input_field, gtk_entry_get_text((GtkEntry*)old->input_field));
            gtk_entry_set_text((GtkEntry*)old->input_field, "");

            // Update new cursor position
            g_signal_emit_by_name((GtkEntry*)win->input_field, "move-cursor", GTK_MOVEMENT_BUFFER_ENDS, -1, FALSE);
            g_signal_emit_by_name((GtkEntry*)win->input_field, "move-cursor", GTK_MOVEMENT_LOGICAL_POSITIONS, cursor_pos, FALSE);
        }
        if (old->command_selector != NULL && win->command_selector != NULL) {
            gtk_combo_box_set_active((GtkComboBox*)win->command_selector, gtk_combo_box_get_active((GtkComboBox*)old->command_selector));
        }
        window_setup(old);
        gtk_widget_show_all(old->window);
    }
    gtk_widget_show_all(win->window);
}

void window_swap_focus(struct Window *win, struct Window *old) {
#ifdef LAYER_SHELL
    if (gtkgreet->use_layer_shell) {
        window_set_focus_layer_shell(win, old);
    }
#endif
    window_set_focus(win, old);
}

void window_configure(struct Window *w) {
#ifdef LAYER_SHELL
    if (gtkgreet->use_layer_shell) {
        window_setup_layershell(w);
    }
#endif

    window_setup(w);
    gtk_widget_show_all(w->window);
}


static gboolean window_background(GtkWidget *widget, cairo_t *cr, gpointer data) {
    gdk_cairo_set_source_pixbuf(cr, gtkgreet->background, 0, 0);
    cairo_paint(cr);
    return FALSE;
}

struct Window *create_window(GdkMonitor *monitor) {
    struct Window *w = calloc(1, sizeof(struct Window));
    if (w == NULL) {
        fprintf(stderr, "failed to allocate Window instance\n");
        exit(1);
    }
    w->monitor = monitor;
    g_array_append_val(gtkgreet->windows, w);

    w->window = gtk_application_window_new(gtkgreet->app);
    g_signal_connect(w->window, "destroy", G_CALLBACK(window_destroy_notify), NULL);
    gtk_window_set_title(GTK_WINDOW(w->window), "Greeter");
    gtk_window_set_default_size(GTK_WINDOW(w->window), 960, 640);
    g_signal_connect(w->window, "key-press-event", G_CALLBACK(window_key_press), w);

    if (gtkgreet->background != NULL) {
        gtk_widget_set_app_paintable(w->window, TRUE);
        g_signal_connect(w->window, "draw", G_CALLBACK(window_background), NULL);
    }
    return w;
}
