#define _POSIX_C_SOURCE 200809L

#include <gtk/gtk.h>

#include <glib/gi18n.h>

#include "window.h"
#include "gtkgreet.h"

struct Window* gtkgreet_window_by_widget(struct GtkGreet *gtkgreet, GtkWidget *window) {
    for (guint idx = 0; idx < gtkgreet->windows->len; idx++) {
        struct Window *ctx = g_array_index(gtkgreet->windows, struct Window*, idx);
        if (ctx->window == window) {
            return ctx;
        }
    }
    return NULL;
}

struct Window* gtkgreet_window_by_monitor(struct GtkGreet *gtkgreet, GdkMonitor *monitor) {
    for (guint idx = 0; idx < gtkgreet->windows->len; idx++) {
        struct Window *ctx = g_array_index(gtkgreet->windows, struct Window*, idx);
        if (ctx->monitor == monitor) {
            return ctx;
        }
    }
    return NULL;
}

void gtkgreet_remove_window_by_widget(struct GtkGreet *gtkgreet, GtkWidget *widget) {
    for (guint idx = 0; idx < gtkgreet->windows->len; idx++) {
        struct Window *ctx = g_array_index(gtkgreet->windows, struct Window*, idx);
        if (ctx->window == widget) {
            if (gtkgreet->focused_window) {
                gtkgreet->focused_window = NULL;
            }
            free(ctx);
            g_array_remove_index_fast(gtkgreet->windows, idx);
            return;
        }
    }
}

void gtkgreet_focus_window(struct GtkGreet *gtkgreet, struct Window* win) {
    struct Window *old = gtkgreet->focused_window;
    gtkgreet->focused_window = win;
    window_swap_focus(win, old);
    for (guint idx = 0; idx < gtkgreet->windows->len; idx++) {
        struct Window *ctx = g_array_index(gtkgreet->windows, struct Window*, idx);
        window_configure(ctx);
    }
}

void gtkgreet_setup_question(struct GtkGreet *gtkgreet, enum QuestionType type, char* question, char* error) {
    /* Callers may retain the current question while adding a validation error. */
    char *new_question = g_strdup(question);
    char *new_error = g_strdup(error);
    if (gtkgreet->question != NULL) {
        free(gtkgreet->question);
        gtkgreet->question = NULL;
    }
    if (gtkgreet->error != NULL) {
        free(gtkgreet->error);
        gtkgreet->error = NULL;
    }
    gtkgreet->question_type = type;
    gtkgreet->question = new_question;
    gtkgreet->error = new_error;
    gtkgreet->question_cnt += 1;
    for (guint idx = 0; idx < gtkgreet->windows->len; idx++) {
        struct Window *ctx = g_array_index(gtkgreet->windows, struct Window*, idx);
        window_configure(ctx);
    }
}

void gtkgreet_set_busy(struct GtkGreet *gtkgreet, gboolean busy) {
    gtkgreet->busy = busy;
    for (guint i = 0; i < gtkgreet->windows->len; i++) {
        struct Window *win = g_array_index(gtkgreet->windows, struct Window*, i);
        if (win->input_field) gtk_widget_set_sensitive(win->input_field, !busy);
        if (win->command_selector) gtk_widget_set_sensitive(win->command_selector, !busy);
        if (win->continue_button) {
            gtk_widget_set_sensitive(win->continue_button, !busy);
            gtk_button_set_label(GTK_BUTTON(win->continue_button), busy ?
                (gtkgreet->cancel_pending ? "Cancelling…" : "Please wait…") : "Continue →");
        }
    }
}

void gtkgreet_update_clocks(struct GtkGreet *gtkgreet) {
    time_t now = time(&now);
    struct tm *now_tm = localtime(&now);
    if (now_tm == NULL) {
        return;
    }
    snprintf(gtkgreet->time, 8, "%02d:%02d", now_tm->tm_hour, now_tm->tm_min);
    for (guint idx = 0; idx < gtkgreet->windows->len; idx++) {
        struct Window *ctx = g_array_index(gtkgreet->windows, struct Window*, idx);
        window_update_clock(ctx);
    }
}

static int gtkgreet_update_clocks_handler(gpointer data) {
    struct GtkGreet *gtkgreet = (struct GtkGreet*)data;
    gtkgreet_update_clocks(gtkgreet);
    return TRUE;
}

struct GtkGreet* create_gtkgreet() {
    GtkSettings *settings = gtk_settings_get_default();
    if (settings != NULL) {
        g_object_set(settings, "gtk-enable-animations", FALSE, "gtk-cursor-blink", FALSE,
            "gtk-entry-password-hint-timeout", 0, NULL);
    }
    gtkgreet = calloc(1, sizeof(struct GtkGreet));
    gtkgreet->app = gtk_application_new("wtf.kl.gtkgreet", G_APPLICATION_DEFAULT_FLAGS);
    gtkgreet->windows = g_array_new(FALSE, TRUE, sizeof(struct Window*));
    gtkgreet->question_cnt = 1;
    g_file_get_contents(GTKGREET_STATE_FILE, &gtkgreet->username, NULL, NULL);
    if (gtkgreet->username != NULL) {
        g_strstrip(gtkgreet->username);
        if (strlen(gtkgreet->username) > 127 ||
            !g_utf8_validate(gtkgreet->username, -1, NULL) ||
            strpbrk(gtkgreet->username, "\r\n") != NULL) {
            g_clear_pointer(&gtkgreet->username, g_free);
        }
    }
    return gtkgreet;
}

void gtkgreet_activate(struct GtkGreet *gtkgreet) {
    gtkgreet->draw_clock_source = g_timeout_add_seconds(5, gtkgreet_update_clocks_handler, gtkgreet);
    gtkgreet_setup_question(gtkgreet, QuestionTypeInitial, gtkgreet_get_initial_question(), NULL);
    gtkgreet_update_clocks(gtkgreet);
}

void gtkgreet_destroy(struct GtkGreet *gtkgreet) {
    if (gtkgreet->question != NULL) {
        free(gtkgreet->question);
        gtkgreet->question = NULL;
    }
    if (gtkgreet->error != NULL) {
        free(gtkgreet->error);
        gtkgreet->error = NULL;
    }

    g_object_unref(gtkgreet->app);
    g_array_unref(gtkgreet->windows);

    if (gtkgreet->draw_clock_source > 0) {
        g_source_remove(gtkgreet->draw_clock_source);
        gtkgreet->draw_clock_source = 0;
    }
    g_free(gtkgreet->username);
    g_free(gtkgreet->selected_command);
    free(gtkgreet);
}

char* gtkgreet_get_initial_question() {
    return _("Username:");
}
