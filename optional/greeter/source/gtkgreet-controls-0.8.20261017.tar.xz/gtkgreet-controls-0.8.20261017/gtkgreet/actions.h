#ifndef _AUTH_QUESTION_H
#define _AUTH_QUESTION_H

#include <gtk/gtk.h>

void action_power(GtkWidget *widget, gpointer data);
void action_answer_question(GtkWidget *widget, gpointer data);
void action_cancel_question(GtkWidget *widget, gpointer data);
void action_use_remembered_user(void);

#endif
