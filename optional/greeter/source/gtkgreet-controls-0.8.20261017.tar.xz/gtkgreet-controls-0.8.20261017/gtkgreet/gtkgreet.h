#ifndef _GTKGREET_H
#define _GTKGREET_H

#include <gtk/gtk.h>

#ifndef GTKGREET_STATE_FILE
#define GTKGREET_STATE_FILE "/var/lib/gtkgreet/last-user"
#endif
#ifndef GTKGREET_SYSTEMCTL
#define GTKGREET_SYSTEMCTL "/usr/bin/systemctl"
#endif


enum QuestionType {
	QuestionTypeInitial = 0,
	QuestionTypeVisible = 1,
	QuestionTypeSecret = 2,
	QuestionTypeInfo = 3,
	QuestionTypeError = 4,
};

// Defined in window.h
struct Window;

struct GtkGreet {
    GtkApplication *app;
    GArray *windows;
    GdkPixbuf *background;

    struct Window *focused_window;
    guint draw_clock_source;

#ifdef LAYER_SHELL
    gboolean use_layer_shell;
#endif
    char* username;
    char* command;

    char* selected_command;
    gboolean busy;
    gboolean cancel_pending;
    gboolean starting_session;
    enum QuestionType question_type;
    char *question;
    char *error;
    char time[8];
    int question_cnt;
};

extern struct GtkGreet *gtkgreet;

struct Window* gtkgreet_window_by_widget(struct GtkGreet *gtkgreet, GtkWidget *window);
struct Window* gtkgreet_window_by_monitor(struct GtkGreet *gtkgreet, GdkMonitor *monitor);
void gtkgreet_remove_window_by_widget(struct GtkGreet *gtkgreet, GtkWidget *widget);
void gtkgreet_focus_window(struct GtkGreet *gtkgreet, struct Window* win);
void gtkgreet_setup_question(struct GtkGreet *gtkgreet, enum QuestionType type, char* question, char* error);
void gtkgreet_set_busy(struct GtkGreet *gtkgreet, gboolean busy);
void gtkgreet_update_clocks(struct GtkGreet *gtkgreet);
struct GtkGreet* create_gtkgreet();
void gtkgreet_activate(struct GtkGreet *gtkgreet);
void gtkgreet_destroy(struct GtkGreet *gtkgreet);
char* gtkgreet_get_initial_question();

#endif
